chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.message === "found_acreditar") {
      alert("Se han encontrado enlaces con la opción 'Acreditar'. Revisa el alistamiento de cursos.");
    }
  });
  