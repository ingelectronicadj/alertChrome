chrome.alarms.create("checkCourses", { periodInMinutes: 5 }); // Ejecutar cada 5 minutos

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "checkCourses") {
    chrome.tabs.query({ url: "https://aurea2.unad.edu.co/oai/*" }, (tabs) => {
      if (tabs.length > 0) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: checkForAcreditarLinks
        });
      }
    });
  }
});

function checkForAcreditarLinks() {
  // Esta función se ejecutará en el contexto de la página.
  let links = document.querySelectorAll('a[href*="acreditar"]');
  if (links.length > 0) {
    chrome.runtime.sendMessage({ message: "found_acreditar" });
  }
}
